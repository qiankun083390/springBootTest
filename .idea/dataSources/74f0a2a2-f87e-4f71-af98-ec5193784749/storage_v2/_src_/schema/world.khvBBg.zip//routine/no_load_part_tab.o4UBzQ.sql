create
    definer = root@`%` procedure no_load_part_tab()
begin
   declare v int default 0;
   while v < 80000000
  do
   insert into no_part_tab
   values (v,'testing partitions',adddate('1995-01-01',(rand(v)*36520) mod 3652));
  set v = v + 1;
  end while;
  end;

